﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GEIMS
{
    public partial class Members : Form
    {
        public Members()
        {
            InitializeComponent();
        }

        private void add_mem_but_Click(object sender, EventArgs e)
        {
            string add_user_var1 = add_mem_user_txt.Text;
            string add_pass_var1 = add_mem_pass_txt.Text;

            validation.add_mem_vali( add_user_var1, add_pass_var1);

            add_mem_user_txt.Text = "";
            add_mem_pass_txt.Text = "";

        }
       
        private void Del_mem_but_Click(object sender, EventArgs e)
        {
            string del_user_var1 = del_mem_txt.Text;
            validation.Del_mem_vali(del_user_var1);
            del_mem_txt.Text = "";
        }

        private void Show_mem_but_Click(object sender, EventArgs e)
        {
            string show_user_var1 = show_mem_txt.Text;
            bool a = validation.Show_mem_vali(show_user_var1);
            if(a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionstring);
                SqlCommand cmd = new SqlCommand("select * from MEMBERS where USERID = '" + show_user_var1 + "'", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                con.Close();
                show_mem.DataSource = dt;
                show_mem_txt.Text = "";
            }
        }

        private void refresh_mem_Click(object sender, EventArgs e)
        {
            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("select * from MEMBERS", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Close();
            show_mem.DataSource = dt;
        }

        private void Members_Load(object sender, EventArgs e)
        {
            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("select * from MEMBERS", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Close();
            show_mem.DataSource = dt;
        }

        public class validation
        {
            internal static void add_mem_vali(string add_user_var2, string add_pass_var2)
            {
                if(add_user_var2.Length <8)
                {
                    MessageBox.Show("Username must contain atleast 8 character.");
                }
                else if (add_pass_var2.Length < 8)
                {
                    MessageBox.Show("Password must contain atleast 8 character.");
                }
                else
                {
                    Dal.add_mem_dal(add_user_var2, add_pass_var2);
                }
            }
            internal static void Del_mem_vali(string del_user_var2)
            {
                if (del_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                }
                else if (del_user_var2.Length < 8)
                {
                    MessageBox.Show("Enter a valid Username !!!!!!e");
                }
                else
                {
                    string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                    string queryString = "select USERID from [dbo].[MEMBERS] where USERID = '" + del_user_var2 + "';";
                    using (SqlConnection connection = new SqlConnection(connectionstring))
                    {
                        using (SqlCommand command = new SqlCommand(queryString, connection))
                        {
                            connection.Open();
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                bool a = reader.Read();
                                if (a)
                                {
                                    string exists = reader.GetString(0);
                                    if (del_user_var2 == exists)
                                    {
                                        Dal.Del_mem_dal(del_user_var2);
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Enter a valid Username !!!!!!");
                                }
                                reader.Close();
                            }
                        }
                    }
                
                }
            }
            internal static bool Show_mem_vali(string show_user_var2)
            {
                if(show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                else if (show_user_var2.Length < 8)
                {
                    MessageBox.Show("Enter a valid Username !!!!!!");
                    return false;
                }
                else
                {
                    string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                    string queryString = "select USERID from [dbo].[MEMBERS] where USERID = '" + show_user_var2 + "';";
                    using (SqlConnection connection = new SqlConnection(connectionstring))
                    {
                        using (SqlCommand command = new SqlCommand(queryString, connection))
                        {
                            connection.Open();
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                bool a = reader.Read();
                                if (a)
                                {
                                    string exists = reader.GetString(0);
                                    reader.Close();
                                    if (show_user_var2 == exists)
                                    {
                                        return true;
                                    }
                                    else
                                    {
                                        MessageBox.Show("NO record Found");
                                        return false;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("NO Match Found");
                                    return false;
                                } 
                            }
                        }
                    }
                }
            }
        }
        public class Dal
        {
            internal static void add_mem_dal(string add_user_var3, string add_pass_var3)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("ADD_LOGIN", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@USERID ", add_user_var3);
                        cmd.Parameters.AddWithValue("@PASS ", add_pass_var3);


                        connection.Open();
                        // to option reader or adpateer
                        //res = cmd.ExecuteNonQuery();
                        int NO = cmd.ExecuteNonQuery();
                        MessageBox.Show("Member Added.");
                        connection.Close();
                    }
                }
            }
            internal static void Del_mem_dal(string del_user_var3)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("DEL_LOGIN", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@USERID ", del_user_var3);
                        connection.Open();
                        // to option reader or adpateer
                        //res = cmd.ExecuteNonQuery();
                        int NO = cmd.ExecuteNonQuery();
                        MessageBox.Show("Member Deleted.");
                        connection.Close();
                    }
                }
            }
        }
    }
}
