﻿
namespace GEIMS
{
    partial class Del_Emp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Del_Emp));
            this.logo_show = new System.Windows.Forms.PictureBox();
            this.heading_show = new System.Windows.Forms.Label();
            this.title_show = new System.Windows.Forms.Label();
            this.recd_gpno_del_label = new System.Windows.Forms.Label();
            this.recd_gpno_del_txt = new System.Windows.Forms.TextBox();
            this.recd_gpno_del_but = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).BeginInit();
            this.SuspendLayout();
            // 
            // logo_show
            // 
            this.logo_show.Image = ((System.Drawing.Image)(resources.GetObject("logo_show.Image")));
            this.logo_show.Location = new System.Drawing.Point(12, 12);
            this.logo_show.Name = "logo_show";
            this.logo_show.Size = new System.Drawing.Size(147, 131);
            this.logo_show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_show.TabIndex = 4;
            this.logo_show.TabStop = false;
            // 
            // heading_show
            // 
            this.heading_show.AutoSize = true;
            this.heading_show.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.heading_show.ForeColor = System.Drawing.Color.Red;
            this.heading_show.Location = new System.Drawing.Point(180, 36);
            this.heading_show.Name = "heading_show";
            this.heading_show.Size = new System.Drawing.Size(634, 33);
            this.heading_show.TabIndex = 5;
            this.heading_show.Text = "Goble Electricals Inventory Management System";
            // 
            // title_show
            // 
            this.title_show.AutoSize = true;
            this.title_show.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.title_show.Location = new System.Drawing.Point(180, 104);
            this.title_show.Name = "title_show";
            this.title_show.Size = new System.Drawing.Size(417, 23);
            this.title_show.TabIndex = 6;
            this.title_show.Text = "Delete Data From Emanelment Tender Table";
            // 
            // recd_gpno_del_label
            // 
            this.recd_gpno_del_label.AutoSize = true;
            this.recd_gpno_del_label.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.recd_gpno_del_label.Location = new System.Drawing.Point(67, 205);
            this.recd_gpno_del_label.Name = "recd_gpno_del_label";
            this.recd_gpno_del_label.Size = new System.Drawing.Size(206, 23);
            this.recd_gpno_del_label.TabIndex = 7;
            this.recd_gpno_del_label.Text = "Received Gate Pass no. : ";
            // 
            // recd_gpno_del_txt
            // 
            this.recd_gpno_del_txt.Location = new System.Drawing.Point(295, 205);
            this.recd_gpno_del_txt.Name = "recd_gpno_del_txt";
            this.recd_gpno_del_txt.Size = new System.Drawing.Size(264, 30);
            this.recd_gpno_del_txt.TabIndex = 8;
            // 
            // recd_gpno_del_but
            // 
            this.recd_gpno_del_but.Location = new System.Drawing.Point(295, 285);
            this.recd_gpno_del_but.Name = "recd_gpno_del_but";
            this.recd_gpno_del_but.Size = new System.Drawing.Size(138, 39);
            this.recd_gpno_del_but.TabIndex = 9;
            this.recd_gpno_del_but.Text = "Delete Record";
            this.recd_gpno_del_but.UseVisualStyleBackColor = true;
            this.recd_gpno_del_but.Click += new System.EventHandler(this.recd_gpno_del_but_Click);
            // 
            // Del_Emp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 450);
            this.Controls.Add(this.recd_gpno_del_but);
            this.Controls.Add(this.recd_gpno_del_txt);
            this.Controls.Add(this.recd_gpno_del_label);
            this.Controls.Add(this.title_show);
            this.Controls.Add(this.heading_show);
            this.Controls.Add(this.logo_show);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Del_Emp";
            this.Text = "Del_Emp";
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logo_show;
        private System.Windows.Forms.Label heading_show;
        private System.Windows.Forms.Label title_show;
        private System.Windows.Forms.Label recd_gpno_del_label;
        private System.Windows.Forms.TextBox recd_gpno_del_txt;
        private System.Windows.Forms.Button recd_gpno_del_but;
    }
}