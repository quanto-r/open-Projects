﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GEIMS
{
    public partial class Update_EMP : Form
    {
        public Update_EMP()
        {
            InitializeComponent();
        }

        private void Update_EMP_Load(object sender, EventArgs e)
        {

        }

        private void search_update_Click(object sender, EventArgs e)
        {
            ShowAdded obj = new ShowAdded();
            obj.ShowDialog();
        }

        private void update_delivery_but_Click(object sender, EventArgs e)
        {
            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_DELIVERY", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@REC_GP", textBox7.Text);
                    cmd.Parameters.AddWithValue("@DM_NO ", textBox8.Text);
                    cmd.Parameters.AddWithValue("@DM_DATE ", textBox9.Text);

                    connection.Open();
                    int NO = cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated.");
                    textBox7.Text = "";
                    textBox8.Text = "";
                    textBox9.Text = "";
                    connection.Close();
                }
            }
        }

        private void update_bill_but_Click(object sender, EventArgs e)
        {

            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_BILL", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@REC_GP", textBox1.Text);
                    cmd.Parameters.AddWithValue("@BILL_NO  ", textBox2.Text);
                    cmd.Parameters.AddWithValue("@BILL_DATE ", textBox3.Text);
                    cmd.Parameters.AddWithValue("@BILL_MONTH  ", textBox4.Text);
                    cmd.Parameters.AddWithValue("@BILL_YEAR ", textBox5.Text);
                    cmd.Parameters.AddWithValue("@AMOUNT ", textBox17.Text);

                    connection.Open();
                    int NO = cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated.");
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox17.Text = "";
                    connection.Close();
                }
            }
        }

        private void update_xmer_but_Click(object sender, EventArgs e)
        {

            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_XMER_Details", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@REC_GP", textBox6.Text);
                    cmd.Parameters.AddWithValue("@MO_NO  ", textBox10.Text);
                    cmd.Parameters.AddWithValue("@Capacity ", textBox11.Text);
                    cmd.Parameters.AddWithValue("@MAKE  ", textBox15.Text);
                    cmd.Parameters.AddWithValue("@MAKE_SR_NO ", textBox16.Text);

                    connection.Open();
                    int NO = cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated.");
                    textBox6.Text = "";
                    textBox10.Text = "";
                    textBox11.Text = "";
                    textBox15.Text = "";
                    textBox16.Text = "";
                    connection.Close();
                }
            }
        }

        private void update_rec_wo_but_Click(object sender, EventArgs e)
        {
            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE_REC_WO", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@REC_GP", textBox12.Text);
                    cmd.Parameters.AddWithValue("@WO_NO  ", textBox13.Text);
                    cmd.Parameters.AddWithValue("@WO_DATE ", textBox14.Text);

                    connection.Open();
                    int NO = cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated.");
                    textBox12.Text = "";
                    textBox13.Text = "";
                    textBox14.Text = "";
                    connection.Close();
                }
            }
        }

        
    }
}
