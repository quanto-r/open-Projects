﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GEIMS
{
    public class GEIMS_exception : ApplicationException
    {
        public GEIMS_exception()
            : base()
        {

        }

        public GEIMS_exception(string message)
            : base(message)
        {

        }

        public GEIMS_exception(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}



