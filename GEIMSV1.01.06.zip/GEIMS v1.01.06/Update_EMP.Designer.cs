﻿
namespace GEIMS
{
    partial class Update_EMP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Update_EMP));
            this.logo_show = new System.Windows.Forms.PictureBox();
            this.heading_show = new System.Windows.Forms.Label();
            this.title_show = new System.Windows.Forms.Label();
            this.search_update = new System.Windows.Forms.Button();
            this.search_update_logo = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.update_xmer_but = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.update_bill_but = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.update_rec_wo_but = new System.Windows.Forms.Button();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.update_delivery_but = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.MaskedTextBox();
            this.textBox9 = new System.Windows.Forms.MaskedTextBox();
            this.textBox14 = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_update_logo)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // logo_show
            // 
            this.logo_show.Image = ((System.Drawing.Image)(resources.GetObject("logo_show.Image")));
            this.logo_show.Location = new System.Drawing.Point(23, 21);
            this.logo_show.Name = "logo_show";
            this.logo_show.Size = new System.Drawing.Size(147, 131);
            this.logo_show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_show.TabIndex = 5;
            this.logo_show.TabStop = false;
            // 
            // heading_show
            // 
            this.heading_show.AutoSize = true;
            this.heading_show.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.heading_show.ForeColor = System.Drawing.Color.Red;
            this.heading_show.Location = new System.Drawing.Point(204, 44);
            this.heading_show.Name = "heading_show";
            this.heading_show.Size = new System.Drawing.Size(634, 33);
            this.heading_show.TabIndex = 6;
            this.heading_show.Text = "Goble Electricals Inventory Management System";
            // 
            // title_show
            // 
            this.title_show.AutoSize = true;
            this.title_show.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.title_show.Location = new System.Drawing.Point(204, 101);
            this.title_show.Name = "title_show";
            this.title_show.Size = new System.Drawing.Size(417, 23);
            this.title_show.TabIndex = 7;
            this.title_show.Text = "Delete Data From Emanelment Tender Table";
            // 
            // search_update
            // 
            this.search_update.Location = new System.Drawing.Point(1270, 44);
            this.search_update.Name = "search_update";
            this.search_update.Size = new System.Drawing.Size(173, 80);
            this.search_update.TabIndex = 8;
            this.search_update.Text = "search_update";
            this.search_update.UseVisualStyleBackColor = true;
            this.search_update.Click += new System.EventHandler(this.search_update_Click);
            // 
            // search_update_logo
            // 
            this.search_update_logo.Image = ((System.Drawing.Image)(resources.GetObject("search_update_logo.Image")));
            this.search_update_logo.Location = new System.Drawing.Point(1105, 12);
            this.search_update_logo.Name = "search_update_logo";
            this.search_update_logo.Size = new System.Drawing.Size(147, 136);
            this.search_update_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.search_update_logo.TabIndex = 9;
            this.search_update_logo.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.update_xmer_but);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox11);
            this.panel1.Controls.Add(this.textBox15);
            this.panel1.Controls.Add(this.textBox16);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox10);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Location = new System.Drawing.Point(784, 173);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(348, 593);
            this.panel1.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 299);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 23);
            this.label11.TabIndex = 13;
            this.label11.Text = "Make Sr. no.";
            // 
            // update_xmer_but
            // 
            this.update_xmer_but.Location = new System.Drawing.Point(88, 353);
            this.update_xmer_but.Name = "update_xmer_but";
            this.update_xmer_but.Size = new System.Drawing.Size(141, 36);
            this.update_xmer_but.TabIndex = 12;
            this.update_xmer_but.Text = "UPDATE";
            this.update_xmer_but.UseVisualStyleBackColor = true;
            this.update_xmer_but.Click += new System.EventHandler(this.update_xmer_but_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(22, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "UPDATE Transformer detials";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(156, 184);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(156, 30);
            this.textBox11.TabIndex = 14;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(156, 242);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(156, 30);
            this.textBox15.TabIndex = 14;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(156, 299);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(156, 30);
            this.textBox16.TabIndex = 14;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(156, 76);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(156, 30);
            this.textBox6.TabIndex = 14;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(156, 132);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(156, 30);
            this.textBox10.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 23);
            this.label2.TabIndex = 13;
            this.label2.Text = "Recd. GP no. :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 23);
            this.label10.TabIndex = 13;
            this.label10.Text = "Make :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 132);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 23);
            this.label8.TabIndex = 13;
            this.label8.Text = "MO no. :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 184);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 23);
            this.label9.TabIndex = 13;
            this.label9.Text = "Capacity :";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.textBox17);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.update_bill_but);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(397, 173);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(358, 593);
            this.panel3.TabIndex = 11;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(163, 235);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(156, 30);
            this.textBox4.TabIndex = 14;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(163, 346);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(156, 30);
            this.textBox17.TabIndex = 14;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(163, 292);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(156, 30);
            this.textBox5.TabIndex = 14;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(163, 125);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(156, 30);
            this.textBox2.TabIndex = 14;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(163, 69);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(156, 30);
            this.textBox1.TabIndex = 14;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(31, 132);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 23);
            this.label15.TabIndex = 13;
            this.label15.Text = "BIll no. :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(31, 353);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 23);
            this.label16.TabIndex = 13;
            this.label16.Text = "Amount";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(31, 242);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 23);
            this.label13.TabIndex = 13;
            this.label13.Text = "Bill Month :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 184);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 23);
            this.label7.TabIndex = 13;
            this.label7.Text = "Bill Date :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(31, 299);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 23);
            this.label14.TabIndex = 13;
            this.label14.Text = "BIll Year";
            // 
            // update_bill_but
            // 
            this.update_bill_but.Location = new System.Drawing.Point(96, 418);
            this.update_bill_but.Name = "update_bill_but";
            this.update_bill_but.Size = new System.Drawing.Size(141, 36);
            this.update_bill_but.TabIndex = 12;
            this.update_bill_but.Text = "Update";
            this.update_bill_but.UseVisualStyleBackColor = true;
            this.update_bill_but.Click += new System.EventHandler(this.update_bill_but_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(31, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 23);
            this.label12.TabIndex = 13;
            this.label12.Text = "Recd. GP no. :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(119, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 28);
            this.label4.TabIndex = 0;
            this.label4.Text = "UPDATE BILL";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel4.Controls.Add(this.textBox14);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.update_rec_wo_but);
            this.panel4.Controls.Add(this.textBox13);
            this.panel4.Controls.Add(this.textBox12);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(1154, 173);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(340, 593);
            this.panel4.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(25, 184);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(87, 23);
            this.label19.TabIndex = 13;
            this.label19.Text = "WO date :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(25, 132);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 23);
            this.label18.TabIndex = 13;
            this.label18.Text = "WO no. :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(25, 76);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 23);
            this.label17.TabIndex = 13;
            this.label17.Text = "Recd. GP no. :";
            // 
            // update_rec_wo_but
            // 
            this.update_rec_wo_but.Location = new System.Drawing.Point(90, 254);
            this.update_rec_wo_but.Name = "update_rec_wo_but";
            this.update_rec_wo_but.Size = new System.Drawing.Size(141, 36);
            this.update_rec_wo_but.TabIndex = 12;
            this.update_rec_wo_but.Text = "UPDATE";
            this.update_rec_wo_but.UseVisualStyleBackColor = true;
            this.update_rec_wo_but.Click += new System.EventHandler(this.update_rec_wo_but_Click);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(165, 132);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(156, 30);
            this.textBox13.TabIndex = 14;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(165, 73);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(156, 30);
            this.textBox12.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(25, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(296, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "UPDATE Received Work Order";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 23);
            this.label5.TabIndex = 13;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 23);
            this.label6.TabIndex = 13;
            this.label6.Text = "label5";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel2.Controls.Add(this.textBox9);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.textBox7);
            this.panel2.Controls.Add(this.update_delivery_but);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Location = new System.Drawing.Point(12, 173);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(340, 593);
            this.panel2.TabIndex = 14;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(25, 184);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(125, 23);
            this.label20.TabIndex = 13;
            this.label20.Text = "Delivery Date : ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(25, 132);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(108, 23);
            this.label21.TabIndex = 13;
            this.label21.Text = "Delivery no. :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(25, 76);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(106, 23);
            this.label22.TabIndex = 13;
            this.label22.Text = "Rec. GP no. :";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(155, 129);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(156, 30);
            this.textBox8.TabIndex = 14;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(155, 73);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(156, 30);
            this.textBox7.TabIndex = 14;
            // 
            // update_delivery_but
            // 
            this.update_delivery_but.Location = new System.Drawing.Point(93, 274);
            this.update_delivery_but.Name = "update_delivery_but";
            this.update_delivery_but.Size = new System.Drawing.Size(141, 36);
            this.update_delivery_but.TabIndex = 12;
            this.update_delivery_but.Text = "UPDATE";
            this.update_delivery_but.UseVisualStyleBackColor = true;
            this.update_delivery_but.Click += new System.EventHandler(this.update_delivery_but_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(25, 21);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(247, 28);
            this.label23.TabIndex = 0;
            this.label23.Text = "UPDATE Delivery Details";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(163, 184);
            this.textBox3.Mask = "00/00/0000";
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(156, 30);
            this.textBox3.TabIndex = 15;
            this.textBox3.ValidatingType = typeof(System.DateTime);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(156, 177);
            this.textBox9.Mask = "00/00/0000";
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(156, 30);
            this.textBox9.TabIndex = 15;
            this.textBox9.ValidatingType = typeof(System.DateTime);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(165, 184);
            this.textBox14.Mask = "00/00/0000";
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(156, 30);
            this.textBox14.TabIndex = 15;
            this.textBox14.ValidatingType = typeof(System.DateTime);
            // 
            // Update_EMP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1529, 796);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.search_update_logo);
            this.Controls.Add(this.search_update);
            this.Controls.Add(this.title_show);
            this.Controls.Add(this.heading_show);
            this.Controls.Add(this.logo_show);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Update_EMP";
            this.Text = "Update_EMP";
            this.Load += new System.EventHandler(this.Update_EMP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_update_logo)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logo_show;
        private System.Windows.Forms.Label heading_show;
        private System.Windows.Forms.Label title_show;
        private System.Windows.Forms.Button search_update;
        private System.Windows.Forms.PictureBox search_update_logo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button update_xmer_but;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button update_bill_but;
        private System.Windows.Forms.Button update_rec_wo_but;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button update_delivery_but;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.MaskedTextBox textBox3;
        private System.Windows.Forms.MaskedTextBox textBox14;
        private System.Windows.Forms.MaskedTextBox textBox9;
    }
}