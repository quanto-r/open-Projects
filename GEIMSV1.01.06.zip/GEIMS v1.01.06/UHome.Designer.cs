﻿
namespace GEIMS
{
    partial class UHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UHome));
            this.dev_credits2 = new System.Windows.Forms.Button();
            this.logo_uhome = new System.Windows.Forms.PictureBox();
            this.heading_uhome = new System.Windows.Forms.Label();
            this.subheading_uhome = new System.Windows.Forms.Label();
            this.insert_logo2 = new System.Windows.Forms.PictureBox();
            this.update_logo2 = new System.Windows.Forms.PictureBox();
            this.delete_logo2 = new System.Windows.Forms.PictureBox();
            this.search_logo2 = new System.Windows.Forms.PictureBox();
            this.insert_but2 = new System.Windows.Forms.Button();
            this.update_but2 = new System.Windows.Forms.Button();
            this.delete_but2 = new System.Windows.Forms.Button();
            this.search_but4 = new System.Windows.Forms.Button();
            this.exit_logo1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.logo_uhome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.insert_logo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.update_logo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delete_logo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_logo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_logo1)).BeginInit();
            this.SuspendLayout();
            // 
            // dev_credits2
            // 
            this.dev_credits2.Location = new System.Drawing.Point(12, 457);
            this.dev_credits2.Name = "dev_credits2";
            this.dev_credits2.Size = new System.Drawing.Size(819, 29);
            this.dev_credits2.TabIndex = 0;
            this.dev_credits2.Text = "Developer Credits";
            this.dev_credits2.UseVisualStyleBackColor = true;
            this.dev_credits2.Click += new System.EventHandler(this.dev_credits2_Click);
            // 
            // logo_uhome
            // 
            this.logo_uhome.Image = ((System.Drawing.Image)(resources.GetObject("logo_uhome.Image")));
            this.logo_uhome.Location = new System.Drawing.Point(12, 12);
            this.logo_uhome.Name = "logo_uhome";
            this.logo_uhome.Size = new System.Drawing.Size(148, 121);
            this.logo_uhome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_uhome.TabIndex = 1;
            this.logo_uhome.TabStop = false;
            // 
            // heading_uhome
            // 
            this.heading_uhome.AutoSize = true;
            this.heading_uhome.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.heading_uhome.ForeColor = System.Drawing.Color.Red;
            this.heading_uhome.Location = new System.Drawing.Point(188, 12);
            this.heading_uhome.Name = "heading_uhome";
            this.heading_uhome.Size = new System.Drawing.Size(643, 33);
            this.heading_uhome.TabIndex = 2;
            this.heading_uhome.Text = "Globle Electricals Inventory Management System";
            // 
            // subheading_uhome
            // 
            this.subheading_uhome.AutoSize = true;
            this.subheading_uhome.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.subheading_uhome.ForeColor = System.Drawing.Color.Black;
            this.subheading_uhome.Location = new System.Drawing.Point(188, 77);
            this.subheading_uhome.Name = "subheading_uhome";
            this.subheading_uhome.Size = new System.Drawing.Size(215, 23);
            this.subheading_uhome.TabIndex = 3;
            this.subheading_uhome.Text = "Accountant Homepage";
            // 
            // insert_logo2
            // 
            this.insert_logo2.Image = ((System.Drawing.Image)(resources.GetObject("insert_logo2.Image")));
            this.insert_logo2.Location = new System.Drawing.Point(46, 179);
            this.insert_logo2.Name = "insert_logo2";
            this.insert_logo2.Size = new System.Drawing.Size(125, 134);
            this.insert_logo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.insert_logo2.TabIndex = 5;
            this.insert_logo2.TabStop = false;
            // 
            // update_logo2
            // 
            this.update_logo2.Image = ((System.Drawing.Image)(resources.GetObject("update_logo2.Image")));
            this.update_logo2.Location = new System.Drawing.Point(244, 179);
            this.update_logo2.Name = "update_logo2";
            this.update_logo2.Size = new System.Drawing.Size(136, 134);
            this.update_logo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.update_logo2.TabIndex = 6;
            this.update_logo2.TabStop = false;
            // 
            // delete_logo2
            // 
            this.delete_logo2.Image = ((System.Drawing.Image)(resources.GetObject("delete_logo2.Image")));
            this.delete_logo2.Location = new System.Drawing.Point(454, 179);
            this.delete_logo2.Name = "delete_logo2";
            this.delete_logo2.Size = new System.Drawing.Size(146, 134);
            this.delete_logo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.delete_logo2.TabIndex = 7;
            this.delete_logo2.TabStop = false;
            // 
            // search_logo2
            // 
            this.search_logo2.Image = ((System.Drawing.Image)(resources.GetObject("search_logo2.Image")));
            this.search_logo2.Location = new System.Drawing.Point(660, 179);
            this.search_logo2.Name = "search_logo2";
            this.search_logo2.Size = new System.Drawing.Size(148, 134);
            this.search_logo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.search_logo2.TabIndex = 9;
            this.search_logo2.TabStop = false;
            // 
            // insert_but2
            // 
            this.insert_but2.Location = new System.Drawing.Point(46, 347);
            this.insert_but2.Name = "insert_but2";
            this.insert_but2.Size = new System.Drawing.Size(125, 72);
            this.insert_but2.TabIndex = 11;
            this.insert_but2.Text = "Add Data";
            this.insert_but2.UseVisualStyleBackColor = true;
            this.insert_but2.Click += new System.EventHandler(this.insert_but2_Click);
            // 
            // update_but2
            // 
            this.update_but2.Location = new System.Drawing.Point(244, 347);
            this.update_but2.Name = "update_but2";
            this.update_but2.Size = new System.Drawing.Size(136, 72);
            this.update_but2.TabIndex = 12;
            this.update_but2.Text = "Update Data";
            this.update_but2.UseVisualStyleBackColor = true;
            this.update_but2.Click += new System.EventHandler(this.update_but2_Click);
            // 
            // delete_but2
            // 
            this.delete_but2.Location = new System.Drawing.Point(454, 347);
            this.delete_but2.Name = "delete_but2";
            this.delete_but2.Size = new System.Drawing.Size(146, 72);
            this.delete_but2.TabIndex = 13;
            this.delete_but2.Text = "Delete Data";
            this.delete_but2.UseVisualStyleBackColor = true;
            this.delete_but2.Click += new System.EventHandler(this.delete_but2_Click);
            // 
            // search_but4
            // 
            this.search_but4.Location = new System.Drawing.Point(660, 347);
            this.search_but4.Name = "search_but4";
            this.search_but4.Size = new System.Drawing.Size(148, 72);
            this.search_but4.TabIndex = 14;
            this.search_but4.Text = "Show Data";
            this.search_but4.UseVisualStyleBackColor = true;
            this.search_but4.Click += new System.EventHandler(this.search_but4_Click);
            // 
            // exit_logo1
            // 
            this.exit_logo1.Image = ((System.Drawing.Image)(resources.GetObject("exit_logo1.Image")));
            this.exit_logo1.Location = new System.Drawing.Point(739, 71);
            this.exit_logo1.Name = "exit_logo1";
            this.exit_logo1.Size = new System.Drawing.Size(69, 62);
            this.exit_logo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exit_logo1.TabIndex = 15;
            this.exit_logo1.TabStop = false;
            this.exit_logo1.Click += new System.EventHandler(this.exit_logo1_Click);
            // 
            // UHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 498);
            this.Controls.Add(this.exit_logo1);
            this.Controls.Add(this.search_but4);
            this.Controls.Add(this.delete_but2);
            this.Controls.Add(this.update_but2);
            this.Controls.Add(this.insert_but2);
            this.Controls.Add(this.search_logo2);
            this.Controls.Add(this.delete_logo2);
            this.Controls.Add(this.update_logo2);
            this.Controls.Add(this.insert_logo2);
            this.Controls.Add(this.subheading_uhome);
            this.Controls.Add(this.heading_uhome);
            this.Controls.Add(this.logo_uhome);
            this.Controls.Add(this.dev_credits2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UHome";
            this.Text = "UHome";
            ((System.ComponentModel.ISupportInitialize)(this.logo_uhome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.insert_logo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.update_logo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delete_logo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_logo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_logo1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button dev_credits2;
        private System.Windows.Forms.PictureBox logo_uhome;
        private System.Windows.Forms.Label heading_uhome;
        private System.Windows.Forms.Label subheading_uhome;
        private System.Windows.Forms.PictureBox insert_logo2;
        private System.Windows.Forms.PictureBox update_logo2;
        private System.Windows.Forms.PictureBox delete_logo2;
        private System.Windows.Forms.PictureBox search_logo2;
        private System.Windows.Forms.Button insert_but2;
        private System.Windows.Forms.Button update_but2;
        private System.Windows.Forms.Button delete_but2;
        private System.Windows.Forms.Button search_but4;
        private System.Windows.Forms.PictureBox exit_logo1;
    }
}