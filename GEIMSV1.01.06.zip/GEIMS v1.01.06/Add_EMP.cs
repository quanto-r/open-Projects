﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GEIMS
{
    public partial class Add_EMP : Form
    {
        public Add_EMP()
        {
            InitializeComponent();
        }

        private void show_addeddata_but_Click(object sender, EventArgs e)
        {
            ShowAdded sdt = new ShowAdded();
            sdt.ShowDialog();
        }

        private void Add_EMP_Load(object sender, EventArgs e)
        {
            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("select * from EMP_TEN_COL_DETAILS", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Close();
            show_col_details.DataSource = dt;
        }

        private void Insert_but_Click(object sender, EventArgs e)
        {
            /*  decimal WO_NO = Convert.ToInt64(textBox5.Text);
             *              int Capacity =  Convert.ToInt32(textBox8.Text);
             *              string DM_DATE = maskedTextBox4.Text;//date
             *              int BILL_YEAR = Convert.ToInt32(textBox16.Text);
             */
            string REC_GPNO = textBox1.Text;
            string REC_DATE= maskedTextBox3.Text;
            string WO_STAT = comboBox1.Text;
            string JOB_NO = textBox4.Text;
            string WO_NO = textBox5.Text;
            string WO_DATE = maskedTextBox1.Text;//date
            string MO_NO = textBox7.Text;
            string Capacity = textBox8.Text;
            string MAKE =  textBox9.Text;
            string MAKE_SR_NO = textBox10.Text;
            string DM_NO = textBox11.Text;
            string DM_DATE = maskedTextBox4.Text;//date
            string BILL_NO =textBox13.Text;
            string BILL_DATE = maskedTextBox2.Text;//date
            string BILL_MONTH = comboBox2.Text;
            string BILL_YEAR = textBox16.Text;
            string AMOUNT = textBox17.Text;
            
            bool a = Insert_vali(REC_GPNO, REC_DATE, WO_STAT, JOB_NO, WO_NO, WO_DATE, MO_NO, Capacity, MAKE, MAKE_SR_NO, DM_NO, DM_DATE, BILL_NO, BILL_DATE, BILL_MONTH, BILL_YEAR, AMOUNT);

            if (a)
            {
                textBox1.Text = "";
                maskedTextBox3.Text = "";
                comboBox1.SelectedIndex = 0;
                textBox4.Text = "";
                textBox5.Text = "";
                maskedTextBox1.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                maskedTextBox4.Text = "";
                textBox13.Text = "";
                maskedTextBox2.Text = "";
                comboBox2.Text = "";
                textBox16.Text = "";
                textBox17.Text = "";
            }
        }


        static bool Insert_vali(string REC_GPNO1, string REC_DATE1, string WO_STAT1, string JOB_NO1, string WO_NO1, string WO_DATE1, string MO_NO1, string Capacity1, string MAKE1, string MAKE_SR_NO1, string DM_NO1, string DM_DATE1, string BILL_NO1, string BILL_DATE1, string BILL_MONTH1, string BILL_YEAR1, string AMOUNT1)
        {
            bool by = Microsoft.VisualBasic.Information.IsNumeric(BILL_YEAR1);
            bool dm = Microsoft.VisualBasic.Information.IsNumeric(DM_NO1); 
            bool ca = Microsoft.VisualBasic.Information.IsNumeric(Capacity1);
            bool wo = Microsoft.VisualBasic.Information.IsNumeric(WO_NO1);

            bool wochk = string.IsNullOrEmpty(Convert.ToString(WO_NO1));
            bool cachk = string.IsNullOrEmpty(Convert.ToString(Capacity1));
            bool dmchk = string.IsNullOrEmpty(Convert.ToString(DM_NO1));
            bool bychk = string.IsNullOrEmpty(Convert.ToString(BILL_YEAR1));
            if (REC_GPNO1 == "")
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (REC_GPNO1.Length < 4)
            {
                MessageBox.Show("Enter a valid Gate Pass number !!!!!!");
                return false;
            }
            else if (REC_DATE1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (WO_STAT1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (JOB_NO1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (wochk)
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (wo == false)
            {
                MessageBox.Show("Please enter BILL year In NUMERICS.");
                return false;
            }
            else if (by == false)
            {
                MessageBox.Show("Please enter BILL year In NUMERICS.");
                return false;
            }
            else if (WO_DATE1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (cachk)
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (ca == false)
            {
                MessageBox.Show("Please enter BILL year In NUMERICS.");
                return false;
            }
            else if (MAKE1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (MAKE_SR_NO1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if ( dmchk)
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (dm == false)
            {
                MessageBox.Show("Please enter Delivery No. In NUMERICS.");
                return false;
            }
            else if (DM_DATE1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (BILL_NO1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (BILL_DATE1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (BILL_MONTH1 == "" )
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (bychk)
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else if (by == false)
            {
                MessageBox.Show("Please enter BILL year In NUMERICS.");
                return false;
            }
            else if ( AMOUNT1 == "")
            {
                MessageBox.Show("Fill All Data (MO No is optional* ).");
                return false;
            }
            else
            {
                bool b = Insert_dal(REC_GPNO1, REC_DATE1, WO_STAT1, JOB_NO1, WO_NO1, WO_DATE1, MO_NO1, Capacity1, MAKE1, MAKE_SR_NO1, DM_NO1, DM_DATE1, BILL_NO1, BILL_DATE1, BILL_MONTH1, BILL_YEAR1, AMOUNT1);
                return b;
            }

        }
        static bool Insert_dal(string REC_GPNO3, string REC_DATE3, string WO_STAT3, string JOB_NO3, string WO_NO3, string WO_DATE3, string MO_NO3, string Capacity3, string MAKE3, string MAKE_SR_NO3, string DM_NO3, string DM_DATE3, string BILL_NO3, string BILL_DATE3, string BILL_MONTH3, string BILL_YEAR3, string AMOUNT3)
        {
            decimal WO_NO = Convert.ToInt64(WO_NO3);
            int Capacity =  Convert.ToInt32(Capacity3);
            string DM_DATE = DM_DATE3;//date
            int BILL_YEAR = Convert.ToInt32(BILL_YEAR3);
            string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("ADD_DATA", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@REC_GPNO ", REC_GPNO3);
                    cmd.Parameters.AddWithValue("@REC_DATE ", REC_DATE3);//date
                    cmd.Parameters.AddWithValue("@WO_STAT ", WO_STAT3);
                    cmd.Parameters.AddWithValue("@JOB_NO ", JOB_NO3);
                    cmd.Parameters.AddWithValue("@WO_NO ", WO_NO);
                    cmd.Parameters.AddWithValue("@WO_DATE ", WO_DATE3);//date
                    cmd.Parameters.AddWithValue("@MO_NO ", MO_NO3);
                    cmd.Parameters.AddWithValue("@Capacity ", Capacity);
                    cmd.Parameters.AddWithValue("@MAKE ", MAKE3);
                    cmd.Parameters.AddWithValue("@MAKE_SR_NO ", MAKE_SR_NO3);
                    cmd.Parameters.AddWithValue("@DM_NO ", DM_NO3);
                    cmd.Parameters.AddWithValue("@DM_DATE ", DM_DATE);//date
                    cmd.Parameters.AddWithValue("@BILL_NO", BILL_NO3);
                    cmd.Parameters.AddWithValue("@BILL_DATE ", BILL_DATE3);//date
                    cmd.Parameters.AddWithValue("@BILL_MONTH ", BILL_MONTH3);
                    cmd.Parameters.AddWithValue("@BILL_YEAR ", BILL_YEAR);
                    cmd.Parameters.AddWithValue("@AMOUNT ", AMOUNT3);


                    connection.Open();
                    int NO = cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Successfully Added to Empanelment Table");
                    connection.Close();
                    return true;
                }
            }
        }
    }
}
