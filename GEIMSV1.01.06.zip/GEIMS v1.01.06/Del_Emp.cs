﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GEIMS
{
    public partial class Del_Emp : Form
    {
        public Del_Emp()
        {
            InitializeComponent();
        }

        private void recd_gpno_del_but_Click(object sender, EventArgs e)
        {
            string del_user_var1 = recd_gpno_del_txt.Text;
            recd_gpno_del_vali(del_user_var1);
            recd_gpno_del_txt.Text = "";


            static void recd_gpno_del_vali(string del_user_var2)
            { 
                bool b1 = Microsoft.VisualBasic.Information.IsNumeric(del_user_var2);
                if(del_user_var2 == "")
                {
                    MessageBox.Show("This Cannot be Empty.");
                }
                else if (b1 == false)
                {
                    MessageBox.Show("Please enter In NUMERICS.");
                }
                else if (del_user_var2.Length < 4)
                {
                    MessageBox.Show("Enter a valid Gate Pass number !!!!!!");
                }
                else
                {
                    recd_gpno_del_dal(del_user_var2);
                }
            }

            static void recd_gpno_del_dal(string del_user_var3)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("DEL_DATA", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@REC_GP ", Convert.ToInt32(del_user_var3));
                        connection.Open();
                        int NO = cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Deleted.");
                        connection.Close();
                    }
                }
            }

        }
    }
}
