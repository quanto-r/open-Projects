﻿
namespace GEIMS
{
    partial class Dhome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dhome));
            this.logo_dhome = new System.Windows.Forms.PictureBox();
            this.heading_dhome = new System.Windows.Forms.Label();
            this.subheading_dhome = new System.Windows.Forms.Label();
            this.dev_credits1 = new System.Windows.Forms.Button();
            this.member_logo = new System.Windows.Forms.PictureBox();
            this.insert_logo1 = new System.Windows.Forms.PictureBox();
            this.update_logo1 = new System.Windows.Forms.PictureBox();
            this.delete_logo1 = new System.Windows.Forms.PictureBox();
            this.exit_logo = new System.Windows.Forms.PictureBox();
            this.search_logo1 = new System.Windows.Forms.PictureBox();
            this.members_but = new System.Windows.Forms.Button();
            this.insert_but1 = new System.Windows.Forms.Button();
            this.update_but1 = new System.Windows.Forms.Button();
            this.delete_but1 = new System.Windows.Forms.Button();
            this.search_but1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logo_dhome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.member_logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.insert_logo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.update_logo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delete_logo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_logo1)).BeginInit();
            this.SuspendLayout();
            // 
            // logo_dhome
            // 
            this.logo_dhome.Image = ((System.Drawing.Image)(resources.GetObject("logo_dhome.Image")));
            this.logo_dhome.Location = new System.Drawing.Point(12, 12);
            this.logo_dhome.Name = "logo_dhome";
            this.logo_dhome.Size = new System.Drawing.Size(144, 123);
            this.logo_dhome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_dhome.TabIndex = 0;
            this.logo_dhome.TabStop = false;
            // 
            // heading_dhome
            // 
            this.heading_dhome.AutoSize = true;
            this.heading_dhome.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.heading_dhome.ForeColor = System.Drawing.Color.Red;
            this.heading_dhome.Location = new System.Drawing.Point(188, 12);
            this.heading_dhome.Name = "heading_dhome";
            this.heading_dhome.Size = new System.Drawing.Size(643, 33);
            this.heading_dhome.TabIndex = 1;
            this.heading_dhome.Text = "Globle Electricals Inventory Management System";
            // 
            // subheading_dhome
            // 
            this.subheading_dhome.AutoSize = true;
            this.subheading_dhome.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.subheading_dhome.ForeColor = System.Drawing.Color.Black;
            this.subheading_dhome.Location = new System.Drawing.Point(188, 69);
            this.subheading_dhome.Name = "subheading_dhome";
            this.subheading_dhome.Size = new System.Drawing.Size(188, 23);
            this.subheading_dhome.TabIndex = 1;
            this.subheading_dhome.Text = "Director Homepage";
            // 
            // dev_credits1
            // 
            this.dev_credits1.Location = new System.Drawing.Point(3, 524);
            this.dev_credits1.Name = "dev_credits1";
            this.dev_credits1.Size = new System.Drawing.Size(903, 29);
            this.dev_credits1.TabIndex = 2;
            this.dev_credits1.Text = "Developer Credits";
            this.dev_credits1.UseVisualStyleBackColor = true;
            this.dev_credits1.Click += new System.EventHandler(this.dev_credits1_Click);
            // 
            // member_logo
            // 
            this.member_logo.Image = ((System.Drawing.Image)(resources.GetObject("member_logo.Image")));
            this.member_logo.Location = new System.Drawing.Point(31, 175);
            this.member_logo.Name = "member_logo";
            this.member_logo.Size = new System.Drawing.Size(125, 134);
            this.member_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.member_logo.TabIndex = 3;
            this.member_logo.TabStop = false;
            // 
            // insert_logo1
            // 
            this.insert_logo1.Image = ((System.Drawing.Image)(resources.GetObject("insert_logo1.Image")));
            this.insert_logo1.Location = new System.Drawing.Point(188, 175);
            this.insert_logo1.Name = "insert_logo1";
            this.insert_logo1.Size = new System.Drawing.Size(125, 134);
            this.insert_logo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.insert_logo1.TabIndex = 4;
            this.insert_logo1.TabStop = false;
            // 
            // update_logo1
            // 
            this.update_logo1.Image = ((System.Drawing.Image)(resources.GetObject("update_logo1.Image")));
            this.update_logo1.Location = new System.Drawing.Point(340, 175);
            this.update_logo1.Name = "update_logo1";
            this.update_logo1.Size = new System.Drawing.Size(136, 134);
            this.update_logo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.update_logo1.TabIndex = 5;
            this.update_logo1.TabStop = false;
            // 
            // delete_logo1
            // 
            this.delete_logo1.Image = ((System.Drawing.Image)(resources.GetObject("delete_logo1.Image")));
            this.delete_logo1.Location = new System.Drawing.Point(511, 175);
            this.delete_logo1.Name = "delete_logo1";
            this.delete_logo1.Size = new System.Drawing.Size(146, 134);
            this.delete_logo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.delete_logo1.TabIndex = 6;
            this.delete_logo1.TabStop = false;
            // 
            // exit_logo
            // 
            this.exit_logo.Image = ((System.Drawing.Image)(resources.GetObject("exit_logo.Image")));
            this.exit_logo.Location = new System.Drawing.Point(808, 438);
            this.exit_logo.Name = "exit_logo";
            this.exit_logo.Size = new System.Drawing.Size(65, 61);
            this.exit_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exit_logo.TabIndex = 7;
            this.exit_logo.TabStop = false;
            this.exit_logo.Click += new System.EventHandler(this.exit_logo_Click);
            // 
            // search_logo1
            // 
            this.search_logo1.Image = ((System.Drawing.Image)(resources.GetObject("search_logo1.Image")));
            this.search_logo1.Location = new System.Drawing.Point(683, 175);
            this.search_logo1.Name = "search_logo1";
            this.search_logo1.Size = new System.Drawing.Size(148, 134);
            this.search_logo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.search_logo1.TabIndex = 8;
            this.search_logo1.TabStop = false;
            // 
            // members_but
            // 
            this.members_but.Location = new System.Drawing.Point(31, 337);
            this.members_but.Name = "members_but";
            this.members_but.Size = new System.Drawing.Size(125, 72);
            this.members_but.TabIndex = 9;
            this.members_but.Text = "Manage Members";
            this.members_but.UseVisualStyleBackColor = true;
            this.members_but.Click += new System.EventHandler(this.members_but_Click);
            // 
            // insert_but1
            // 
            this.insert_but1.Location = new System.Drawing.Point(188, 337);
            this.insert_but1.Name = "insert_but1";
            this.insert_but1.Size = new System.Drawing.Size(125, 72);
            this.insert_but1.TabIndex = 10;
            this.insert_but1.Text = "Add Data";
            this.insert_but1.UseVisualStyleBackColor = true;
            this.insert_but1.Click += new System.EventHandler(this.insert_but1_Click);
            // 
            // update_but1
            // 
            this.update_but1.Location = new System.Drawing.Point(340, 337);
            this.update_but1.Name = "update_but1";
            this.update_but1.Size = new System.Drawing.Size(136, 72);
            this.update_but1.TabIndex = 11;
            this.update_but1.Text = "Update Data";
            this.update_but1.UseVisualStyleBackColor = true;
            this.update_but1.Click += new System.EventHandler(this.update_but1_Click);
            // 
            // delete_but1
            // 
            this.delete_but1.Location = new System.Drawing.Point(511, 337);
            this.delete_but1.Name = "delete_but1";
            this.delete_but1.Size = new System.Drawing.Size(146, 72);
            this.delete_but1.TabIndex = 12;
            this.delete_but1.Text = "Delete Data";
            this.delete_but1.UseVisualStyleBackColor = true;
            this.delete_but1.Click += new System.EventHandler(this.delete_but1_Click);
            // 
            // search_but1
            // 
            this.search_but1.Location = new System.Drawing.Point(683, 337);
            this.search_but1.Name = "search_but1";
            this.search_but1.Size = new System.Drawing.Size(148, 72);
            this.search_but1.TabIndex = 13;
            this.search_but1.Text = "Show Data";
            this.search_but1.UseVisualStyleBackColor = true;
            this.search_but1.Click += new System.EventHandler(this.search_but1_Click);
            // 
            // Dhome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 554);
            this.Controls.Add(this.search_but1);
            this.Controls.Add(this.delete_but1);
            this.Controls.Add(this.update_but1);
            this.Controls.Add(this.insert_but1);
            this.Controls.Add(this.members_but);
            this.Controls.Add(this.search_logo1);
            this.Controls.Add(this.exit_logo);
            this.Controls.Add(this.delete_logo1);
            this.Controls.Add(this.update_logo1);
            this.Controls.Add(this.insert_logo1);
            this.Controls.Add(this.member_logo);
            this.Controls.Add(this.dev_credits1);
            this.Controls.Add(this.subheading_dhome);
            this.Controls.Add(this.heading_dhome);
            this.Controls.Add(this.logo_dhome);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Dhome";
            this.Text = "Dhome";
            ((System.ComponentModel.ISupportInitialize)(this.logo_dhome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.member_logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.insert_logo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.update_logo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delete_logo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_logo1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logo_dhome;
        private System.Windows.Forms.Label heading_dhome;
        private System.Windows.Forms.Label subheading_dhome;
        private System.Windows.Forms.Button dev_credits1;
        private System.Windows.Forms.PictureBox member_logo;
        private System.Windows.Forms.PictureBox insert_logo1;
        private System.Windows.Forms.PictureBox update_logo1;
        private System.Windows.Forms.PictureBox delete_logo1;
        private System.Windows.Forms.PictureBox exit_logo;
        private System.Windows.Forms.PictureBox search_logo1;
        private System.Windows.Forms.Button members_but;
        private System.Windows.Forms.Button insert_but1;
        private System.Windows.Forms.Button update_but1;
        private System.Windows.Forms.Button delete_but1;
        private System.Windows.Forms.Button search_but1;
    }
}