﻿
namespace GEIMS
{
    partial class ShowAdded
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShowAdded));
            this.Show_added_data = new System.Windows.Forms.DataGridView();
            this.Export = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Show_added_data)).BeginInit();
            this.SuspendLayout();
            // 
            // Show_added_data
            // 
            this.Show_added_data.BackgroundColor = System.Drawing.Color.LightBlue;
            this.Show_added_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Show_added_data.GridColor = System.Drawing.Color.DimGray;
            this.Show_added_data.Location = new System.Drawing.Point(3, 62);
            this.Show_added_data.Name = "Show_added_data";
            this.Show_added_data.RowHeadersWidth = 51;
            this.Show_added_data.RowTemplate.Height = 32;
            this.Show_added_data.Size = new System.Drawing.Size(1442, 649);
            this.Show_added_data.TabIndex = 0;
            // 
            // Export
            // 
            this.Export.ForeColor = System.Drawing.Color.Red;
            this.Export.Location = new System.Drawing.Point(31, 13);
            this.Export.Name = "Export";
            this.Export.Size = new System.Drawing.Size(134, 43);
            this.Export.TabIndex = 1;
            this.Export.Text = "Export";
            this.Export.UseVisualStyleBackColor = true;
            this.Export.Click += new System.EventHandler(this.Export_Click);
            // 
            // ShowAdded
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1457, 735);
            this.Controls.Add(this.Export);
            this.Controls.Add(this.Show_added_data);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ShowAdded";
            this.Text = "ShowAdded";
            this.Load += new System.EventHandler(this.ShowAdded_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Show_added_data)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Show_added_data;
        private System.Windows.Forms.Button Export;
    }
}