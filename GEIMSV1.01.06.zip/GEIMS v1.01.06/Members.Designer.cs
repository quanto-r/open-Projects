﻿
namespace GEIMS
{
    partial class Members
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Members));
            this.logo_show = new System.Windows.Forms.PictureBox();
            this.heading_show = new System.Windows.Forms.Label();
            this.title_show = new System.Windows.Forms.Label();
            this.show_mem_txt = new System.Windows.Forms.TextBox();
            this.add_mem_pass_txt = new System.Windows.Forms.TextBox();
            this.add_mem_user_txt = new System.Windows.Forms.TextBox();
            this.del_mem_txt = new System.Windows.Forms.TextBox();
            this.Pass_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.add_mem_but = new System.Windows.Forms.Button();
            this.Show_mem_but = new System.Windows.Forms.Button();
            this.Del_mem_but = new System.Windows.Forms.Button();
            this.show_mem = new System.Windows.Forms.DataGridView();
            this.refresh_mem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.show_mem)).BeginInit();
            this.SuspendLayout();
            // 
            // logo_show
            // 
            this.logo_show.Image = ((System.Drawing.Image)(resources.GetObject("logo_show.Image")));
            this.logo_show.Location = new System.Drawing.Point(12, 12);
            this.logo_show.Name = "logo_show";
            this.logo_show.Size = new System.Drawing.Size(147, 131);
            this.logo_show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_show.TabIndex = 2;
            this.logo_show.TabStop = false;
            // 
            // heading_show
            // 
            this.heading_show.AutoSize = true;
            this.heading_show.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.heading_show.ForeColor = System.Drawing.Color.Red;
            this.heading_show.Location = new System.Drawing.Point(189, 37);
            this.heading_show.Name = "heading_show";
            this.heading_show.Size = new System.Drawing.Size(634, 33);
            this.heading_show.TabIndex = 3;
            this.heading_show.Text = "Goble Electricals Inventory Management System";
            // 
            // title_show
            // 
            this.title_show.AutoSize = true;
            this.title_show.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.title_show.Location = new System.Drawing.Point(189, 102);
            this.title_show.Name = "title_show";
            this.title_show.Size = new System.Drawing.Size(220, 23);
            this.title_show.TabIndex = 4;
            this.title_show.Text = "Manage User Members";
            // 
            // show_mem_txt
            // 
            this.show_mem_txt.Location = new System.Drawing.Point(148, 334);
            this.show_mem_txt.Name = "show_mem_txt";
            this.show_mem_txt.Size = new System.Drawing.Size(250, 30);
            this.show_mem_txt.TabIndex = 5;
            // 
            // add_mem_pass_txt
            // 
            this.add_mem_pass_txt.Location = new System.Drawing.Point(533, 186);
            this.add_mem_pass_txt.Name = "add_mem_pass_txt";
            this.add_mem_pass_txt.Size = new System.Drawing.Size(250, 30);
            this.add_mem_pass_txt.TabIndex = 5;
            // 
            // add_mem_user_txt
            // 
            this.add_mem_user_txt.Location = new System.Drawing.Point(148, 186);
            this.add_mem_user_txt.Name = "add_mem_user_txt";
            this.add_mem_user_txt.Size = new System.Drawing.Size(250, 30);
            this.add_mem_user_txt.TabIndex = 5;
            // 
            // del_mem_txt
            // 
            this.del_mem_txt.Location = new System.Drawing.Point(533, 334);
            this.del_mem_txt.Name = "del_mem_txt";
            this.del_mem_txt.Size = new System.Drawing.Size(250, 30);
            this.del_mem_txt.TabIndex = 6;
            // 
            // Pass_label
            // 
            this.Pass_label.AutoSize = true;
            this.Pass_label.Location = new System.Drawing.Point(441, 189);
            this.Pass_label.Name = "Pass_label";
            this.Pass_label.Size = new System.Drawing.Size(51, 23);
            this.Pass_label.TabIndex = 7;
            this.Pass_label.Text = "Pass :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "User ID :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(441, 334);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "User ID :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "User ID :";
            // 
            // add_mem_but
            // 
            this.add_mem_but.Location = new System.Drawing.Point(303, 243);
            this.add_mem_but.Name = "add_mem_but";
            this.add_mem_but.Size = new System.Drawing.Size(278, 66);
            this.add_mem_but.TabIndex = 8;
            this.add_mem_but.Text = "ADD Member";
            this.add_mem_but.UseVisualStyleBackColor = true;
            this.add_mem_but.Click += new System.EventHandler(this.add_mem_but_Click);
            // 
            // Show_mem_but
            // 
            this.Show_mem_but.Location = new System.Drawing.Point(148, 383);
            this.Show_mem_but.Name = "Show_mem_but";
            this.Show_mem_but.Size = new System.Drawing.Size(250, 40);
            this.Show_mem_but.TabIndex = 8;
            this.Show_mem_but.Text = "Show Member";
            this.Show_mem_but.UseVisualStyleBackColor = true;
            this.Show_mem_but.Click += new System.EventHandler(this.Show_mem_but_Click);
            // 
            // Del_mem_but
            // 
            this.Del_mem_but.Location = new System.Drawing.Point(533, 383);
            this.Del_mem_but.Name = "Del_mem_but";
            this.Del_mem_but.Size = new System.Drawing.Size(250, 40);
            this.Del_mem_but.TabIndex = 8;
            this.Del_mem_but.Text = "Delete Member";
            this.Del_mem_but.UseVisualStyleBackColor = true;
            this.Del_mem_but.Click += new System.EventHandler(this.Del_mem_but_Click);
            // 
            // show_mem
            // 
            this.show_mem.AllowUserToAddRows = false;
            this.show_mem.AllowUserToDeleteRows = false;
            this.show_mem.AllowUserToOrderColumns = true;
            this.show_mem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.show_mem.BackgroundColor = System.Drawing.Color.LightBlue;
            this.show_mem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.show_mem.Location = new System.Drawing.Point(12, 488);
            this.show_mem.Name = "show_mem";
            this.show_mem.ReadOnly = true;
            this.show_mem.RowHeadersWidth = 51;
            this.show_mem.RowTemplate.Height = 32;
            this.show_mem.Size = new System.Drawing.Size(811, 289);
            this.show_mem.TabIndex = 9;
            // 
            // refresh_mem
            // 
            this.refresh_mem.Location = new System.Drawing.Point(303, 448);
            this.refresh_mem.Name = "refresh_mem";
            this.refresh_mem.Size = new System.Drawing.Size(278, 29);
            this.refresh_mem.TabIndex = 10;
            this.refresh_mem.Text = "Refresh";
            this.refresh_mem.UseVisualStyleBackColor = true;
            this.refresh_mem.Click += new System.EventHandler(this.refresh_mem_Click);
            // 
            // Members
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 789);
            this.Controls.Add(this.refresh_mem);
            this.Controls.Add(this.show_mem);
            this.Controls.Add(this.Del_mem_but);
            this.Controls.Add(this.Show_mem_but);
            this.Controls.Add(this.add_mem_but);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Pass_label);
            this.Controls.Add(this.del_mem_txt);
            this.Controls.Add(this.add_mem_pass_txt);
            this.Controls.Add(this.add_mem_user_txt);
            this.Controls.Add(this.show_mem_txt);
            this.Controls.Add(this.title_show);
            this.Controls.Add(this.heading_show);
            this.Controls.Add(this.logo_show);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Members";
            this.Text = "Members";
            this.Load += new System.EventHandler(this.Members_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.show_mem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logo_show;
        private System.Windows.Forms.Label heading_show;
        private System.Windows.Forms.Label title_show;
        private System.Windows.Forms.TextBox show_mem_txt;
        private System.Windows.Forms.TextBox add_mem_pass_txt;
        private System.Windows.Forms.TextBox add_mem_user_txt;
        private System.Windows.Forms.TextBox del_mem_txt;
        private System.Windows.Forms.Label Pass_label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button add_mem_but;
        private System.Windows.Forms.Button Show_mem_but;
        private System.Windows.Forms.Button Del_mem_but;
        private System.Windows.Forms.DataGridView show_mem;
        private System.Windows.Forms.Button refresh_mem;
    }
}