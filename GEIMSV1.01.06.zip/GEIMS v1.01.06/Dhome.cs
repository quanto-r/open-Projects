﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GEIMS
{
    public partial class Dhome : Form
    {
        public Dhome()
        {
            InitializeComponent();
        }

        private void members_but_Click(object sender, EventArgs e)
        {
            Members obj = new Members();
            obj.ShowDialog();
        }

        private void insert_but1_Click(object sender, EventArgs e)
        {
            Add_EMP obj1 = new Add_EMP();
            obj1.ShowDialog();
        }

        private void update_but1_Click(object sender, EventArgs e)
        {
            Update_EMP obj2 = new Update_EMP();
            obj2.ShowDialog();
        }

        private void delete_but1_Click(object sender, EventArgs e)
        {
            Del_Emp obj3 = new Del_Emp();
            obj3.ShowDialog();
        }

        private void search_but1_Click(object sender, EventArgs e)
        {
            Show_EMP obj4 = new Show_EMP();
            obj4.ShowDialog();
        }

        private void exit_logo_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Login obj5 = new Login();
            obj5.ShowDialog();
        }

        private void dev_credits1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Application is Developed by Ritik Nagpure And Khushal Jadhav");
        }
    }
}