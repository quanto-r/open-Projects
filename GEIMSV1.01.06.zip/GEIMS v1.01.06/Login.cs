﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GEIMS
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Clear_button_Click(object sender, EventArgs e)
        {
            userin_txt.Text = "";
            passin_txt.Text = "";
        }

        private void Exit_logo0_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Login_button_Click(object sender, EventArgs e)
        {
            string userin_txt_val1 = userin_txt.Text;
            string passin_txt_val1 = passin_txt.Text;

            int fin = vali.validate(userin_txt_val1, passin_txt_val1);

            if (fin == 1)
            {
                userin_txt.Text = "";
                passin_txt.Text = "";
                this.Visible = false;
                Dhome objdhome = new Dhome();
                objdhome.ShowDialog();
                
            }
            if (fin == 2)
            {
                userin_txt.Text = "";
                passin_txt.Text = "";      
                this.Visible = false;
                UHome objuhome = new UHome();
                objuhome.ShowDialog();

            }
        }
        
        private class vali
        {
            internal static int validate(string userin_txt_val1, string passin_txt_val1)
            {
                string userin_txt_val2 = userin_txt_val1;
                string passin_txt_val2 = passin_txt_val1;
                if (userin_txt_val2 == "")
                {
                    MessageBox.Show("Cannot leave Username Empty");
                    return 0;
                }
                else if (passin_txt_val2 == "")
                {
                    MessageBox.Show("Cannot leave Password Empty");
                    return 0;
                }
                else if (userin_txt_val2.Length < 8 || passin_txt_val2.Length < 8)
                {
                    MessageBox.Show("Username and Password Cannot be less than 8 characters.");
                    return 0;
                }
                else
                {
                    int dalout = login_dal(userin_txt_val2, passin_txt_val2);
                    return dalout;
                }

            } 

            static int login_dal(string userin_txt_val, string passin_txt_val)
            {
                if (userin_txt_val == "Director" && passin_txt_val == "Director123")
                {
                    MessageBox.Show("Hello Director!!!! you have logged in succesfully");
  //                  Dhome objdhome = new Dhome();
 //                   objdhome.ShowDialog();
                    return 1;
                }
                else
                {
                    string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                    string queryString = "select PASS from [dbo].[MEMBERS] where USERID = '" + userin_txt_val + "';";
                    using (SqlConnection connection = new SqlConnection(connectionstring))
                    {
                        using (SqlCommand command = new SqlCommand(queryString, connection))
                        {
                            connection.Open();
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                bool a = reader.Read();
                                if(a)
                                {
                                    string pass_val = reader.GetString(0);
                                    reader.Close();
                                    string userin_val = userin_txt_val;
                                    if (userin_txt_val == userin_val && passin_txt_val == pass_val)
                                    {
                                        MessageBox.Show("Hello Accountant!!!! you have logged in succesfully");
                                   //     UHome objuhome = new UHome();
                                    //    objuhome.ShowDialog();
                                        return 2;
                                        
                                    }
                                    return 0;
                                }
                                else
                                {
                                    MessageBox.Show("Invalid ID or Password.");
                                    return 0;
                                }
                                
                            }
                        }
                    }
                }

            }
        }

    }
}
