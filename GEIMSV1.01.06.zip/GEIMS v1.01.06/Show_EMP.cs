﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GEIMS
{
    public partial class Show_EMP : Form
    {
        public Show_EMP()
        {
            InitializeComponent();
        }
        private void Export_Click(object sender, EventArgs e)
        {

            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application(); 
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            app.Visible = true;
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            worksheet.Name = "Exported from gridview"; 
            for (int i = 1; i < Show_EMP_data.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = Show_EMP_data.Columns[i - 1].HeaderText;
            }
            for (int i = 0; i < Show_EMP_data.Rows.Count - 1; i++)
            {
                for (int j = 0; j < Show_EMP_data.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = Show_EMP_data.Rows[i].Cells[j].Value.ToString();
                }
            } 
            workbook.SaveAs("G:\\Files\\College project\\Show EMP\\output.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            app.Quit();
        } 

        private void Show_EMP_Load(object sender, EventArgs e)
        {

        }

        private void Showby_GPNo_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_GPNo_txt.Text;
            bool a = validation.Showby_GPNo_vali(show_user_var1);
            if (a)
            {
                
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_GPNO", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@REC_GP ", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                        Showby_GPNo_txt.Text = "";
                    }
                }
            }
            
        }

        private void Showby_recddate_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_recddate_txt.Text;
            bool a = validation.Showby_recddate_vali(show_user_var1);
            if (a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_REC_DATE", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@REC_DATE ", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        Showby_recddate_txt.Text = "";
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                    }
                }
            }
            
            
        }
            
        private void Showby_DMno_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_DMno_txt.Text;
            bool a = validation.Showby_DMno_vali(show_user_var1);
            if (a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_DMNO", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DM_NO", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        Showby_DMno_txt.Text = "";
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                    }
                }
            }                    
        }

        private void Showby_DMdate_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_DMdate_txt.Text;
            bool a = validation.Showby_DMdate_vali(show_user_var1);
            if (a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_DMDATE", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DM_DATE", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        Showby_DMdate_txt.Text = "";
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                    }
                }
            }  
        }

        private void Showby_Capacity_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_Capacity_txt.Text;
            bool a = validation.Showby_Capacity_vali(show_user_var1);
            if (a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_CAPACITY", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Capacity", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        Showby_Capacity_txt.Text = "";
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                    }
                }
            }  
        }

        private void Showby_Billdate_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_Billdate_txt.Text;
            bool a = validation.Showby_Billdate_vali(show_user_var1);
            if (a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_BILL_DATE", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@BILL_DATE", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        Showby_Billdate_txt.Text = "";
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                    }
                }
            }
        }

        private void Showby_Billmonth_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_Billmonth_txt.Text;
            bool a = validation.Showby_Billmonth_vali(show_user_var1);
            if (a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_BILL_MONTH", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@BILL_MONTH", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        Showby_Billmonth_txt.Text = "";
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                    }
                }
            }
        }
        
        private void Showby_Billyear_show_Click(object sender, EventArgs e)
        {
            string show_user_var1 = Showby_Billyear_txt.Text;
            bool a = validation.Showby_Billyear_vali(show_user_var1);
            if (a)
            {
                string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["GEIMS_string"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("SHOW_BY_BILL_YEAR", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@BILL_YEAR", show_user_var1);
                        connection.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        Showby_Billyear_txt.Text = "";
                        connection.Close();
                        Show_EMP_data.DataSource = dt;
                    }
                }
            } 
        }

        public class validation
        {
            internal static bool Showby_GPNo_vali(string show_user_var2)
            {
                if (show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                bool b1 = Microsoft.VisualBasic.Information.IsNumeric(show_user_var2);
                if (b1 == false)
                {
                    MessageBox.Show("Please enter In NUMERICS.");
                    return false;
                }
                else if (show_user_var2.Length < 4)
                {
                    MessageBox.Show("Enter a valid Gate Pass number !!!!!!");
                    return false;
                }
                else
                {
                    return true;
                }
            }
      
            internal static bool Showby_recddate_vali(string show_user_var2)
            {
                if (show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                else if (show_user_var2.Length < 8)
                {
                    MessageBox.Show("Enter a valid Gate Pass Receieve Date !!!!!!");
                    return false;
                }
                else
                {
                    return true;
                }
            }

            internal static bool Showby_DMno_vali(string show_user_var2)
            {
                if (show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                bool b1 = Microsoft.VisualBasic.Information.IsNumeric(show_user_var2);
                if (b1 == false)
                {
                    MessageBox.Show("Please enter In NUMERICS.");
                    return false;
                }
                else
                {
                    return true;
                }
            }

            internal static bool Showby_DMdate_vali(string show_user_var2)
            {
                if (show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                else if (show_user_var2.Length < 8)
                {
                    MessageBox.Show("Enter a valid Delivery Date !!!!!!");
                    return false;
                }
                else
                {
                    return true;
                }
            }

            internal static bool Showby_Capacity_vali(string show_user_var2)
            {
                if (show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                else if (show_user_var2 != "63" && show_user_var2 != "100")
                {
                    MessageBox.Show("Only 63 KV and 100 KV are available.");
                    return false;
                }
                else
                {
                    return true;
                }
            }

            internal static bool Showby_Billdate_vali(string show_user_var2)
            {
                if (show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                else if (show_user_var2.Length < 8)
                {
                    MessageBox.Show("Enter a valid Billing Date!!!!!!");
                    return false;
                }
                else
                {
                    return true;
                }
            }

            internal static bool Showby_Billmonth_vali(string show_user_var2)
            {
                if (show_user_var2 == "")
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                else
                {
                    return true;
                }
            }

            internal static bool Showby_Billyear_vali(string show_user_var2)
            {
                bool schk = string.IsNullOrEmpty(show_user_var2);
                if (schk)
                {
                    MessageBox.Show("Cannot leave this feild empty while serching.");
                    return false;
                }
                bool b1 = Microsoft.VisualBasic.Information.IsNumeric(show_user_var2);                
                if (b1 == false)
                {
                    MessageBox.Show("Please enter In NUMERICS.");
                    return false;
                }
                int show_yearchk = Convert.ToInt32(show_user_var2);
                if (show_user_var2.Length != 4)
                {
                    MessageBox.Show("Enter a valid Billing year !!");
                    return false;
                }
                if (show_yearchk <= 1996)
                {
                    MessageBox.Show("NO record Available for the entered year.");
                    return false;
                }
                else
                {
                    return true;
                }
            } 
        }
    }
}
