﻿
namespace GEIMS
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.userin = new System.Windows.Forms.Label();
            this.passin = new System.Windows.Forms.Label();
            this.userin_txt = new System.Windows.Forms.TextBox();
            this.passin_txt = new System.Windows.Forms.TextBox();
            this.Login_button = new System.Windows.Forms.Button();
            this.Clear_button = new System.Windows.Forms.Button();
            this.logo_login = new System.Windows.Forms.PictureBox();
            this.heading_login = new System.Windows.Forms.Label();
            this.Exit_logo0 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.logo_login)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit_logo0)).BeginInit();
            this.SuspendLayout();
            // 
            // userin
            // 
            this.userin.AutoSize = true;
            this.userin.Location = new System.Drawing.Point(213, 229);
            this.userin.Name = "userin";
            this.userin.Size = new System.Drawing.Size(96, 23);
            this.userin.TabIndex = 0;
            this.userin.Text = "Username :";
            // 
            // passin
            // 
            this.passin.AutoSize = true;
            this.passin.Location = new System.Drawing.Point(213, 282);
            this.passin.Name = "passin";
            this.passin.Size = new System.Drawing.Size(89, 23);
            this.passin.TabIndex = 1;
            this.passin.Text = "Password :";
            // 
            // userin_txt
            // 
            this.userin_txt.Location = new System.Drawing.Point(334, 229);
            this.userin_txt.Name = "userin_txt";
            this.userin_txt.Size = new System.Drawing.Size(231, 30);
            this.userin_txt.TabIndex = 2;
            // 
            // passin_txt
            // 
            this.passin_txt.Location = new System.Drawing.Point(334, 282);
            this.passin_txt.Name = "passin_txt";
            this.passin_txt.PasswordChar = '*';
            this.passin_txt.Size = new System.Drawing.Size(231, 30);
            this.passin_txt.TabIndex = 3;
            // 
            // Login_button
            // 
            this.Login_button.ForeColor = System.Drawing.Color.Green;
            this.Login_button.Location = new System.Drawing.Point(334, 344);
            this.Login_button.Name = "Login_button";
            this.Login_button.Size = new System.Drawing.Size(110, 43);
            this.Login_button.TabIndex = 4;
            this.Login_button.Text = "Log In";
            this.Login_button.UseVisualStyleBackColor = true;
            this.Login_button.Click += new System.EventHandler(this.Login_button_Click);
            // 
            // Clear_button
            // 
            this.Clear_button.ForeColor = System.Drawing.Color.Red;
            this.Clear_button.Location = new System.Drawing.Point(464, 344);
            this.Clear_button.Name = "Clear_button";
            this.Clear_button.Size = new System.Drawing.Size(101, 43);
            this.Clear_button.TabIndex = 5;
            this.Clear_button.Text = "Clear";
            this.Clear_button.UseVisualStyleBackColor = true;
            this.Clear_button.Click += new System.EventHandler(this.Clear_button_Click);
            // 
            // logo_login
            // 
            this.logo_login.Image = ((System.Drawing.Image)(resources.GetObject("logo_login.Image")));
            this.logo_login.Location = new System.Drawing.Point(334, 22);
            this.logo_login.Name = "logo_login";
            this.logo_login.Size = new System.Drawing.Size(203, 133);
            this.logo_login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_login.TabIndex = 6;
            this.logo_login.TabStop = false;
            // 
            // heading_login
            // 
            this.heading_login.AutoSize = true;
            this.heading_login.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.heading_login.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.heading_login.ForeColor = System.Drawing.Color.Red;
            this.heading_login.Location = new System.Drawing.Point(120, 171);
            this.heading_login.Name = "heading_login";
            this.heading_login.Size = new System.Drawing.Size(643, 33);
            this.heading_login.TabIndex = 7;
            this.heading_login.Text = "Globle Electricals Inventory Management System";
            // 
            // Exit_logo0
            // 
            this.Exit_logo0.Image = ((System.Drawing.Image)(resources.GetObject("Exit_logo0.Image")));
            this.Exit_logo0.Location = new System.Drawing.Point(710, 379);
            this.Exit_logo0.Name = "Exit_logo0";
            this.Exit_logo0.Size = new System.Drawing.Size(53, 55);
            this.Exit_logo0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Exit_logo0.TabIndex = 8;
            this.Exit_logo0.TabStop = false;
            this.Exit_logo0.Click += new System.EventHandler(this.Exit_logo0_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 484);
            this.Controls.Add(this.Exit_logo0);
            this.Controls.Add(this.heading_login);
            this.Controls.Add(this.logo_login);
            this.Controls.Add(this.Clear_button);
            this.Controls.Add(this.Login_button);
            this.Controls.Add(this.passin_txt);
            this.Controls.Add(this.userin_txt);
            this.Controls.Add(this.passin);
            this.Controls.Add(this.userin);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Login";
            this.Text = "Log In Menu";
            ((System.ComponentModel.ISupportInitialize)(this.logo_login)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exit_logo0)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label userin;
        private System.Windows.Forms.Label passin;
        private System.Windows.Forms.TextBox userin_txt;
        private System.Windows.Forms.TextBox passin_txt;
        private System.Windows.Forms.Button Login_button;
        private System.Windows.Forms.Button Clear_button;
        private System.Windows.Forms.PictureBox logo_login;
        private System.Windows.Forms.Label heading_login;
        private System.Windows.Forms.PictureBox Exit_logo0;
    }
}

