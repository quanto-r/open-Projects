﻿
namespace GEIMS
{
    partial class Show_EMP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Show_EMP));
            this.heading_show = new System.Windows.Forms.Label();
            this.logo_show = new System.Windows.Forms.PictureBox();
            this.title_show = new System.Windows.Forms.Label();
            this.Showby_GPNo = new System.Windows.Forms.Label();
            this.Showby_DMno = new System.Windows.Forms.Label();
            this.Showby_recddate = new System.Windows.Forms.Label();
            this.Showby_DMdate = new System.Windows.Forms.Label();
            this.Showby_Capacity = new System.Windows.Forms.Label();
            this.Showby_Billdate = new System.Windows.Forms.Label();
            this.Showby_Billmonth = new System.Windows.Forms.Label();
            this.Showby_Billyear = new System.Windows.Forms.Label();
            this.Show_EMP_data = new System.Windows.Forms.DataGridView();
            this.Showby_GPNo_txt = new System.Windows.Forms.TextBox();
            this.Showby_DMno_txt = new System.Windows.Forms.TextBox();
            this.Showby_Billyear_txt = new System.Windows.Forms.TextBox();
            this.Showby_GPNo_show = new System.Windows.Forms.Button();
            this.Showby_recddate_show = new System.Windows.Forms.Button();
            this.Showby_DMno_show = new System.Windows.Forms.Button();
            this.Showby_DMdate_show = new System.Windows.Forms.Button();
            this.Showby_Capacity_show = new System.Windows.Forms.Button();
            this.Showby_Billdate_show = new System.Windows.Forms.Button();
            this.Showby_Billmonth_show = new System.Windows.Forms.Button();
            this.Showby_Billyear_show = new System.Windows.Forms.Button();
            this.Export = new System.Windows.Forms.Button();
            this.Showby_Capacity_txt = new System.Windows.Forms.ComboBox();
            this.Showby_Billmonth_txt = new System.Windows.Forms.ComboBox();
            this.Showby_recddate_txt = new System.Windows.Forms.MaskedTextBox();
            this.Showby_DMdate_txt = new System.Windows.Forms.MaskedTextBox();
            this.Showby_Billdate_txt = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Show_EMP_data)).BeginInit();
            this.SuspendLayout();
            // 
            // heading_show
            // 
            this.heading_show.AutoSize = true;
            this.heading_show.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.heading_show.ForeColor = System.Drawing.Color.Red;
            this.heading_show.Location = new System.Drawing.Point(205, 34);
            this.heading_show.Name = "heading_show";
            this.heading_show.Size = new System.Drawing.Size(634, 33);
            this.heading_show.TabIndex = 0;
            this.heading_show.Text = "Goble Electricals Inventory Management System";
            // 
            // logo_show
            // 
            this.logo_show.Image = ((System.Drawing.Image)(resources.GetObject("logo_show.Image")));
            this.logo_show.Location = new System.Drawing.Point(35, 13);
            this.logo_show.Name = "logo_show";
            this.logo_show.Size = new System.Drawing.Size(147, 131);
            this.logo_show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo_show.TabIndex = 1;
            this.logo_show.TabStop = false;
            // 
            // title_show
            // 
            this.title_show.AutoSize = true;
            this.title_show.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.title_show.Location = new System.Drawing.Point(205, 89);
            this.title_show.Name = "title_show";
            this.title_show.Size = new System.Drawing.Size(240, 23);
            this.title_show.TabIndex = 0;
            this.title_show.Text = "Show Empanelment Data";
            // 
            // Showby_GPNo
            // 
            this.Showby_GPNo.AutoSize = true;
            this.Showby_GPNo.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_GPNo.Location = new System.Drawing.Point(35, 166);
            this.Showby_GPNo.Name = "Showby_GPNo";
            this.Showby_GPNo.Size = new System.Drawing.Size(247, 21);
            this.Showby_GPNo.TabIndex = 2;
            this.Showby_GPNo.Text = "Show by Gate Pass number : ";
            // 
            // Showby_DMno
            // 
            this.Showby_DMno.AutoSize = true;
            this.Showby_DMno.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_DMno.Location = new System.Drawing.Point(35, 272);
            this.Showby_DMno.Name = "Showby_DMno";
            this.Showby_DMno.Size = new System.Drawing.Size(239, 21);
            this.Showby_DMno.TabIndex = 2;
            this.Showby_DMno.Text = "Show by Delivery number : ";
            // 
            // Showby_recddate
            // 
            this.Showby_recddate.AutoSize = true;
            this.Showby_recddate.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_recddate.Location = new System.Drawing.Point(31, 220);
            this.Showby_recddate.Name = "Showby_recddate";
            this.Showby_recddate.Size = new System.Drawing.Size(216, 21);
            this.Showby_recddate.TabIndex = 2;
            this.Showby_recddate.Text = "Show by Received Date : ";
            // 
            // Showby_DMdate
            // 
            this.Showby_DMdate.AutoSize = true;
            this.Showby_DMdate.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_DMdate.Location = new System.Drawing.Point(35, 329);
            this.Showby_DMdate.Name = "Showby_DMdate";
            this.Showby_DMdate.Size = new System.Drawing.Size(212, 21);
            this.Showby_DMdate.TabIndex = 2;
            this.Showby_DMdate.Text = "Show by Delivery Date : ";
            // 
            // Showby_Capacity
            // 
            this.Showby_Capacity.AutoSize = true;
            this.Showby_Capacity.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_Capacity.Location = new System.Drawing.Point(808, 166);
            this.Showby_Capacity.Name = "Showby_Capacity";
            this.Showby_Capacity.Size = new System.Drawing.Size(226, 21);
            this.Showby_Capacity.TabIndex = 2;
            this.Showby_Capacity.Text = "Show by Capacity(in KV) : ";
            // 
            // Showby_Billdate
            // 
            this.Showby_Billdate.AutoSize = true;
            this.Showby_Billdate.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_Billdate.Location = new System.Drawing.Point(808, 216);
            this.Showby_Billdate.Name = "Showby_Billdate";
            this.Showby_Billdate.Size = new System.Drawing.Size(170, 21);
            this.Showby_Billdate.TabIndex = 2;
            this.Showby_Billdate.Text = "Show by Bill Date : ";
            // 
            // Showby_Billmonth
            // 
            this.Showby_Billmonth.AutoSize = true;
            this.Showby_Billmonth.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_Billmonth.Location = new System.Drawing.Point(808, 274);
            this.Showby_Billmonth.Name = "Showby_Billmonth";
            this.Showby_Billmonth.Size = new System.Drawing.Size(184, 21);
            this.Showby_Billmonth.TabIndex = 2;
            this.Showby_Billmonth.Text = "Show by Bill Month : ";
            // 
            // Showby_Billyear
            // 
            this.Showby_Billyear.AutoSize = true;
            this.Showby_Billyear.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Showby_Billyear.Location = new System.Drawing.Point(808, 329);
            this.Showby_Billyear.Name = "Showby_Billyear";
            this.Showby_Billyear.Size = new System.Drawing.Size(167, 21);
            this.Showby_Billyear.TabIndex = 2;
            this.Showby_Billyear.Text = "Show by Bill Year : ";
            // 
            // Show_EMP_data
            // 
            this.Show_EMP_data.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Show_EMP_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Show_EMP_data.Location = new System.Drawing.Point(31, 383);
            this.Show_EMP_data.Name = "Show_EMP_data";
            this.Show_EMP_data.RowHeadersWidth = 51;
            this.Show_EMP_data.RowTemplate.Height = 32;
            this.Show_EMP_data.Size = new System.Drawing.Size(1592, 636);
            this.Show_EMP_data.TabIndex = 3;
            // 
            // Showby_GPNo_txt
            // 
            this.Showby_GPNo_txt.Location = new System.Drawing.Point(289, 166);
            this.Showby_GPNo_txt.Name = "Showby_GPNo_txt";
            this.Showby_GPNo_txt.Size = new System.Drawing.Size(255, 30);
            this.Showby_GPNo_txt.TabIndex = 4;
            // 
            // Showby_DMno_txt
            // 
            this.Showby_DMno_txt.Location = new System.Drawing.Point(289, 268);
            this.Showby_DMno_txt.Name = "Showby_DMno_txt";
            this.Showby_DMno_txt.Size = new System.Drawing.Size(255, 30);
            this.Showby_DMno_txt.TabIndex = 4;
            // 
            // Showby_Billyear_txt
            // 
            this.Showby_Billyear_txt.Location = new System.Drawing.Point(1031, 320);
            this.Showby_Billyear_txt.Name = "Showby_Billyear_txt";
            this.Showby_Billyear_txt.Size = new System.Drawing.Size(255, 30);
            this.Showby_Billyear_txt.TabIndex = 5;
            // 
            // Showby_GPNo_show
            // 
            this.Showby_GPNo_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_GPNo_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_GPNo_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_GPNo_show.Location = new System.Drawing.Point(576, 166);
            this.Showby_GPNo_show.Name = "Showby_GPNo_show";
            this.Showby_GPNo_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_GPNo_show.TabIndex = 6;
            this.Showby_GPNo_show.Text = "Show";
            this.Showby_GPNo_show.UseVisualStyleBackColor = false;
            this.Showby_GPNo_show.Click += new System.EventHandler(this.Showby_GPNo_show_Click);
            // 
            // Showby_recddate_show
            // 
            this.Showby_recddate_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_recddate_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_recddate_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_recddate_show.Location = new System.Drawing.Point(576, 216);
            this.Showby_recddate_show.Name = "Showby_recddate_show";
            this.Showby_recddate_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_recddate_show.TabIndex = 6;
            this.Showby_recddate_show.Text = "Show";
            this.Showby_recddate_show.UseVisualStyleBackColor = false;
            this.Showby_recddate_show.Click += new System.EventHandler(this.Showby_recddate_show_Click);
            // 
            // Showby_DMno_show
            // 
            this.Showby_DMno_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_DMno_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_DMno_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_DMno_show.Location = new System.Drawing.Point(576, 268);
            this.Showby_DMno_show.Name = "Showby_DMno_show";
            this.Showby_DMno_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_DMno_show.TabIndex = 6;
            this.Showby_DMno_show.Text = "Show";
            this.Showby_DMno_show.UseVisualStyleBackColor = false;
            this.Showby_DMno_show.Click += new System.EventHandler(this.Showby_DMno_show_Click);
            // 
            // Showby_DMdate_show
            // 
            this.Showby_DMdate_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_DMdate_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_DMdate_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_DMdate_show.Location = new System.Drawing.Point(576, 325);
            this.Showby_DMdate_show.Name = "Showby_DMdate_show";
            this.Showby_DMdate_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_DMdate_show.TabIndex = 6;
            this.Showby_DMdate_show.Text = "Show";
            this.Showby_DMdate_show.UseVisualStyleBackColor = false;
            this.Showby_DMdate_show.Click += new System.EventHandler(this.Showby_DMdate_show_Click);
            // 
            // Showby_Capacity_show
            // 
            this.Showby_Capacity_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_Capacity_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_Capacity_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_Capacity_show.Location = new System.Drawing.Point(1331, 157);
            this.Showby_Capacity_show.Name = "Showby_Capacity_show";
            this.Showby_Capacity_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_Capacity_show.TabIndex = 6;
            this.Showby_Capacity_show.Text = "Show";
            this.Showby_Capacity_show.UseVisualStyleBackColor = false;
            this.Showby_Capacity_show.Click += new System.EventHandler(this.Showby_Capacity_show_Click);
            // 
            // Showby_Billdate_show
            // 
            this.Showby_Billdate_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_Billdate_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_Billdate_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_Billdate_show.Location = new System.Drawing.Point(1331, 207);
            this.Showby_Billdate_show.Name = "Showby_Billdate_show";
            this.Showby_Billdate_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_Billdate_show.TabIndex = 6;
            this.Showby_Billdate_show.Text = "Show";
            this.Showby_Billdate_show.UseVisualStyleBackColor = false;
            this.Showby_Billdate_show.Click += new System.EventHandler(this.Showby_Billdate_show_Click);
            // 
            // Showby_Billmonth_show
            // 
            this.Showby_Billmonth_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_Billmonth_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_Billmonth_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_Billmonth_show.Location = new System.Drawing.Point(1331, 263);
            this.Showby_Billmonth_show.Name = "Showby_Billmonth_show";
            this.Showby_Billmonth_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_Billmonth_show.TabIndex = 6;
            this.Showby_Billmonth_show.Text = "Show";
            this.Showby_Billmonth_show.UseVisualStyleBackColor = false;
            this.Showby_Billmonth_show.Click += new System.EventHandler(this.Showby_Billmonth_show_Click);
            // 
            // Showby_Billyear_show
            // 
            this.Showby_Billyear_show.BackColor = System.Drawing.Color.LightGreen;
            this.Showby_Billyear_show.Font = new System.Drawing.Font("Cambria", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Showby_Billyear_show.ForeColor = System.Drawing.Color.Black;
            this.Showby_Billyear_show.Location = new System.Drawing.Point(1331, 320);
            this.Showby_Billyear_show.Name = "Showby_Billyear_show";
            this.Showby_Billyear_show.Size = new System.Drawing.Size(102, 30);
            this.Showby_Billyear_show.TabIndex = 6;
            this.Showby_Billyear_show.Text = "Show";
            this.Showby_Billyear_show.UseVisualStyleBackColor = false;
            this.Showby_Billyear_show.Click += new System.EventHandler(this.Showby_Billyear_show_Click);
            // 
            // Export
            // 
            this.Export.ForeColor = System.Drawing.Color.Red;
            this.Export.Location = new System.Drawing.Point(1470, 39);
            this.Export.Name = "Export";
            this.Export.Size = new System.Drawing.Size(153, 49);
            this.Export.TabIndex = 7;
            this.Export.Text = "Export";
            this.Export.UseVisualStyleBackColor = true;
            this.Export.Click += new System.EventHandler(this.Export_Click);
            // 
            // Showby_Capacity_txt
            // 
            this.Showby_Capacity_txt.FormattingEnabled = true;
            this.Showby_Capacity_txt.Items.AddRange(new object[] {
            "63",
            "100"});
            this.Showby_Capacity_txt.Location = new System.Drawing.Point(1031, 157);
            this.Showby_Capacity_txt.Name = "Showby_Capacity_txt";
            this.Showby_Capacity_txt.Size = new System.Drawing.Size(255, 31);
            this.Showby_Capacity_txt.TabIndex = 8;
            // 
            // Showby_Billmonth_txt
            // 
            this.Showby_Billmonth_txt.AccessibleRole = System.Windows.Forms.AccessibleRole.ComboBox;
            this.Showby_Billmonth_txt.FormattingEnabled = true;
            this.Showby_Billmonth_txt.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.Showby_Billmonth_txt.Location = new System.Drawing.Point(1031, 272);
            this.Showby_Billmonth_txt.Name = "Showby_Billmonth_txt";
            this.Showby_Billmonth_txt.Size = new System.Drawing.Size(255, 31);
            this.Showby_Billmonth_txt.TabIndex = 9;
            // 
            // Showby_recddate_txt
            // 
            this.Showby_recddate_txt.Location = new System.Drawing.Point(289, 220);
            this.Showby_recddate_txt.Mask = "00/00/0000";
            this.Showby_recddate_txt.Name = "Showby_recddate_txt";
            this.Showby_recddate_txt.Size = new System.Drawing.Size(255, 30);
            this.Showby_recddate_txt.TabIndex = 10;
            this.Showby_recddate_txt.ValidatingType = typeof(System.DateTime);
            // 
            // Showby_DMdate_txt
            // 
            this.Showby_DMdate_txt.Location = new System.Drawing.Point(289, 329);
            this.Showby_DMdate_txt.Mask = "00/00/0000";
            this.Showby_DMdate_txt.Name = "Showby_DMdate_txt";
            this.Showby_DMdate_txt.Size = new System.Drawing.Size(255, 30);
            this.Showby_DMdate_txt.TabIndex = 11;
            this.Showby_DMdate_txt.ValidatingType = typeof(System.DateTime);
            // 
            // Showby_Billdate_txt
            // 
            this.Showby_Billdate_txt.Location = new System.Drawing.Point(1031, 216);
            this.Showby_Billdate_txt.Mask = "00/00/0000";
            this.Showby_Billdate_txt.Name = "Showby_Billdate_txt";
            this.Showby_Billdate_txt.Size = new System.Drawing.Size(255, 30);
            this.Showby_Billdate_txt.TabIndex = 11;
            this.Showby_Billdate_txt.ValidatingType = typeof(System.DateTime);
            // 
            // Show_EMP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1647, 1031);
            this.Controls.Add(this.Showby_Billdate_txt);
            this.Controls.Add(this.Showby_DMdate_txt);
            this.Controls.Add(this.Showby_recddate_txt);
            this.Controls.Add(this.Showby_Billmonth_txt);
            this.Controls.Add(this.Showby_Capacity_txt);
            this.Controls.Add(this.Export);
            this.Controls.Add(this.Showby_Billyear_show);
            this.Controls.Add(this.Showby_Billmonth_show);
            this.Controls.Add(this.Showby_DMdate_show);
            this.Controls.Add(this.Showby_Billdate_show);
            this.Controls.Add(this.Showby_DMno_show);
            this.Controls.Add(this.Showby_Capacity_show);
            this.Controls.Add(this.Showby_recddate_show);
            this.Controls.Add(this.Showby_GPNo_show);
            this.Controls.Add(this.Showby_Billyear_txt);
            this.Controls.Add(this.Showby_DMno_txt);
            this.Controls.Add(this.Showby_GPNo_txt);
            this.Controls.Add(this.Show_EMP_data);
            this.Controls.Add(this.Showby_recddate);
            this.Controls.Add(this.Showby_Billyear);
            this.Controls.Add(this.Showby_Billmonth);
            this.Controls.Add(this.Showby_Billdate);
            this.Controls.Add(this.Showby_Capacity);
            this.Controls.Add(this.Showby_DMdate);
            this.Controls.Add(this.Showby_DMno);
            this.Controls.Add(this.Showby_GPNo);
            this.Controls.Add(this.logo_show);
            this.Controls.Add(this.title_show);
            this.Controls.Add(this.heading_show);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Show_EMP";
            this.Text = "Show_EMP";
            this.Load += new System.EventHandler(this.Show_EMP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logo_show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Show_EMP_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label heading_show;
        private System.Windows.Forms.PictureBox logo_show;
        private System.Windows.Forms.Label title_show;
        private System.Windows.Forms.Label Showby_GPNo;
        private System.Windows.Forms.Label Showby_DMno;
        private System.Windows.Forms.Label Showby_recddate;
        private System.Windows.Forms.Label Showby_DMdate;
        private System.Windows.Forms.Label Showby_Capacity;
        private System.Windows.Forms.Label Showby_Billdate;
        private System.Windows.Forms.Label Showby_Billmonth;
        private System.Windows.Forms.Label Showby_Billyear;
        private System.Windows.Forms.DataGridView Show_EMP_data;
        private System.Windows.Forms.TextBox Showby_GPNo_txt;
        private System.Windows.Forms.TextBox Showby_DMno_txt;
        private System.Windows.Forms.TextBox Showby_Billyear_txt;
        private System.Windows.Forms.Button Showby_GPNo_show;
        private System.Windows.Forms.Button Showby_recddate_show;
        private System.Windows.Forms.Button Showby_DMno_show;
        private System.Windows.Forms.Button Showby_DMdate_show;
        private System.Windows.Forms.Button Showby_Capacity_show;
        private System.Windows.Forms.Button Showby_Billdate_show;
        private System.Windows.Forms.Button Showby_Billmonth_show;
        private System.Windows.Forms.Button Showby_Billyear_show;
        private System.Windows.Forms.Button Export;
        private System.Windows.Forms.ComboBox Showby_Capacity_txt;
        private System.Windows.Forms.ComboBox Showby_Billmonth_txt;
        private System.Windows.Forms.MaskedTextBox Showby_recddate_txt;
        private System.Windows.Forms.MaskedTextBox Showby_DMdate_txt;
        private System.Windows.Forms.MaskedTextBox Showby_Billdate_txt;
    }
}