﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GEIMS
{
    public partial class UHome : Form
    {
        public UHome()
        {
            InitializeComponent();
        }

        private void insert_but2_Click(object sender, EventArgs e)
        {
            Add_EMP obj1 = new Add_EMP();
            obj1.ShowDialog();
        }

        private void update_but2_Click(object sender, EventArgs e)
        {
            Update_EMP obj2 = new Update_EMP();
            obj2.ShowDialog();
        }

        private void delete_but2_Click(object sender, EventArgs e)
        {
            Del_Emp obj3 = new Del_Emp();
            obj3.ShowDialog();
        }

        private void search_but4_Click(object sender, EventArgs e)
        {
            Show_EMP obj4 = new Show_EMP();
            obj4.ShowDialog();
        }

        private void dev_credits2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Application is Developed by Ritik Nagpure and Khushal Jadhav");
        }

        private void exit_logo1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Login obj5 = new Login();
            obj5.ShowDialog();
        }
    }
}
